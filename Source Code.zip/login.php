<?php //login.php
/**
  * File contains login information for mysql
  *
  * @author Albert Yu
  *
  * 
  */
$hn = 'localhost';
$un = 'albert';
$pw = 'password';
$db = 'images';

?>